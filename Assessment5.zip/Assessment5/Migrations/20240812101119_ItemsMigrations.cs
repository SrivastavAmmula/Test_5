﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Assessment5.Migrations
{
    /// <inheritdoc />
    public partial class ItemsMigrations : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Items",
                columns: table => new
                {
                    ITCODE = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false),
                    ITDESC = table.Column<string>(type: "varchar(15)", maxLength: 15, nullable: false),
                    ITRATE = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Items", x => x.ITCODE);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Items");
        }
    }
}
