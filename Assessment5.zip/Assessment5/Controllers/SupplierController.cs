﻿using Assessment5.Entities;
using Assessment5.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assessment5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly ISupplierRepository _supplierRepository;
        public SupplierController(ISupplierRepository supplierRepository)
        {
            _supplierRepository = supplierRepository;
        }

        [HttpGet,Route("GetAllSuppliers")]
        public async Task<IActionResult> GetAllSuppliers()
        {
            var suppliers = await _supplierRepository.GetAll();
            return Ok(suppliers);
        }

        [HttpGet,Route("GetSupplierBySuplno/{suplno}")]
        public async Task<IActionResult> GetSupplierbyId(string suplno)
        {
            var supplier = await _supplierRepository.GetBySuplno(suplno);
            if (supplier == null)
            {
                return NotFound("The supplier is not found");
            }
            return Ok(supplier);
        }

        [HttpPost,Route("AddSupplier")]
        public async Task<IActionResult> AddSupplier(Supplier supplier)
        {
            await _supplierRepository.Add(supplier);
            return Ok("Supplier added successfully");
        }

        [HttpPut,Route("UpdateSupplier")]
        public async Task<IActionResult> UpdateSupplier(Supplier supplier)
        {
            await _supplierRepository.Update(supplier);
            return Ok("Supplier updated successfully");
        }
        [HttpDelete,Route("DeleteSupplier/{suplno}")]
        public async Task<IActionResult> DeleteSupplier(string suplno)
        {
            await _supplierRepository.Delete(suplno);
            return Ok("Supplier deleted successfully");
        }
    }
}
