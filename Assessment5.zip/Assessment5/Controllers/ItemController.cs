﻿using Assessment5.Entities;
using Assessment5.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assessment5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        private readonly IItemRepository _itemRepository;
        public ItemController(IItemRepository itemRepository)
        {
            _itemRepository = itemRepository;
        }
        [HttpGet, Route("GetAllItems")]
        public async Task<IActionResult> GetAllItems()
        {
            var items = await _itemRepository.GetAll();
            return Ok(items);
        }
        [HttpGet, Route("GetItemByITCODE/{itcode}")]

        public async Task<IActionResult> GetItemByITCODE(string itcode)
        {
            var item = await _itemRepository.GetByITCODE(itcode);
            if (item == null)
            {
                return NotFound("The item is not found");
            }
            return Ok(item);
        }
        [HttpPost, Route("AddItem")]
        public async Task<IActionResult> AddItem(Item item)
        {
            await _itemRepository.Add(item);
            return Ok("Item added successfully");
        }
        [HttpPut, Route("UpdateItem")]
        public async Task<IActionResult> UpdateItem(Item item)
        {
            await _itemRepository.Update(item);
            return Ok("Item updated successfully");
        }
        [HttpDelete, Route("DeleteItem/{itcode}")]
        public async Task<IActionResult> DeleteItem(string itcode)
        {
            await _itemRepository.Delete(itcode);
            return Ok("Item deleted successfully");
        }
    }
}
