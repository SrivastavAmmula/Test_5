﻿using Assessment5.Entities;

namespace Assessment5.Repositories
{
    public interface IPomasterRepository
    {
        Task<List<Pomaster>> GetAll();
        Task<Pomaster> GetByPONO(string pono);
        Task Add(Pomaster pomaster);
        Task Update(Pomaster pomaster);
        Task Delete(string pono);
    }
}
